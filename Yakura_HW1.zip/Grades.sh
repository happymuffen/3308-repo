#!/bin/bash
#Ben Yakura

if [ $# -ne 1 ]; then
	echo "Usage: $0 filename"
	exit 2
fi
if [ ! -f $1 ]; then
	echo '$1 is not a valid file'
	exit 2
fi
sort -o tmp -k3,3 -k2,2  $1
chmod +rwx ./tmp

while IFS= read -r aline; do
	line=($aline)
	average=$((${line[3]} + ${line[4]} + ${line[5]}))
	average=$(($average / 3))
	echo $average [${line[0]}] ${line[2]}, ${line[1]}
done <./tmp
rm tmp
